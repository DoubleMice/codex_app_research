import{a2 as n,a8 as o}from"./index-BnRAGF7J.js";var g=n((t,e)=>{let a;return e==="sandbox"&&(a=o("#i"+t)),(e==="sandbox"?o(a.nodes()[0].contentDocument.body):o("body")).select(`[id="${t}"]`)},"getDiagramElement");export{g};
//# sourceMappingURL=chunk-55IACEB6-D8dgPtuT.js.map
