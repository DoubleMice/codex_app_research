import{c as s,j as o,a1 as i}from"./index-BnRAGF7J.js";function l(){const t=s.c(1);let e;return t[0]===Symbol.for("react.memo_cache_sentinel")?(e=o.jsx(i,{}),t[0]=e):e=t[0],e}export{l as SkillsSettings};
//# sourceMappingURL=skills-settings-BzU7clYL.js.map
