import{aw as o,ax as n}from"./index-BnRAGF7J.js";const t=(a,r)=>o.lang.round(n.parse(a)[r]);export{t as c};
//# sourceMappingURL=channel-DF6SLYYj.js.map
