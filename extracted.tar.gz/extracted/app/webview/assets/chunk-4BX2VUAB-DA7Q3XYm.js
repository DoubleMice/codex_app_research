import{a2 as i}from"./index-BnRAGF7J.js";function t(c,e){c.accDescr&&e.setAccDescription?.(c.accDescr),c.accTitle&&e.setAccTitle?.(c.accTitle),c.title&&e.setDiagramTitle?.(c.title)}i(t,"populateCommonDb");export{t as p};
//# sourceMappingURL=chunk-4BX2VUAB-DA7Q3XYm.js.map
